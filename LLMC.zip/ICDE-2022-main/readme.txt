Code for the clustering model: LLMC.

Run 'demo_leaves.m' in Matlab to perform LLMC.